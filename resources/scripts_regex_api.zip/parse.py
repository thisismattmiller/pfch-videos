import glob
import json
import re

cm_pattern = re.compile(r'([0-9]+\.*[0-9]*)\s+[×|x|X]\s([0-9]+\.*[0-9]*)\s*[c|C][m|M]')
in_pattern = re.compile(r'([0-9]+)\s*([0-9]*)/*([0-9]*)\s+[x|X|×]\s([0-9]+)\s*([0-9]*)/*([0-9]*)\s*in')
#metphoto

#->data
#-->*.json
#download.py
#parse.py
#data/*.json
size_lookup = {}

has_dimensions = 0
for filename in glob.glob('data/*.json'):
	# print(filename)
	with open(filename,'r') as jsonfile:
		data = json.load(jsonfile)
		if data['dimensions'] != '':
			has_dimensions+=1
			
			cm_width = None
			cm_height = None

			cm_search = cm_pattern.search(data['dimensions'])
			if cm_search == None:

				in_search = in_pattern.search(data['dimensions'])

				if in_search != None:


					# lets do width
					if in_search.group(2) == "":
						# wdith is not a fraction.
						cm_width = int(in_search.group(1)) * 2.54		
					else:
						#width is a fraction
						width_decimal = int(in_search.group(2)) / int(in_search.group(3))
						cm_width = (int(in_search.group(1)) * 2.54) + (2.54 * width_decimal)

					# lets do height
					if in_search.group(5) == "":
						# height is whole number
						cm_height = int(in_search.group(4)) * 2.54
					else:
						# height is a fraction number
						height_decimal = int(in_search.group(5)) / int(in_search.group(6))
						cm_height = (int(in_search.group(4)) * 2.54) + (2.54 * height_decimal)
				else:
					print('NOT CM & NOT IN',data['dimensions'])
					
			else:
				cm_width = cm_search.group(1)
				cm_height = cm_search.group(2)

				# print(cm_width, cm_height)

			if cm_width != None and cm_height != None:
				# get to this point WE HAVE DATATA

				lookup_key = f'{cm_width}x{cm_height}'
				if lookup_key not in size_lookup:
					size_lookup[lookup_key] = 0

				size_lookup[lookup_key]+=1


with open('size_results.json','w') as out:
	json.dump(size_lookup,out,indent=2)

